"""Attached record environments govern computed values and their cache.

No SQL is needed. These controls cover descriptor/environment integration,
not database routing or the full field access-control contract.
"""

from django.db import models
import pytest

import api
import fields
from orm import registry
from orm.environments import (
    context_scope,
    env as ambient_env,
    get_context,
    is_su,
    transaction_scope,
)
from orm.fields import FieldDescriptor
from orm.models import BaseModel


class RecordEnvironmentProbe(BaseModel):
    _name = 'orm.record.environment.probe'
    rendered = fields.Char(compute='_compute_rendered')
    ambient_value = fields.Char(compute='_compute_ambient_value')
    failing = fields.Char(compute='_compute_failing')
    privileged = fields.Boolean(compute='_compute_privileged')

    class Meta:
        app_label = 'contenttypes'
        managed = False

    @api.depends_context('probe_key')
    def _compute_rendered(self):
        self.rendered = self.env.context.get('probe_key', 'missing')

    @api.depends_context('probe_key')
    def _compute_ambient_value(self):
        self.ambient_value = get_context().get('probe_key', 'missing')

    @api.depends_context('probe_key')
    def _compute_failing(self):
        raise RuntimeError('compute failed')

    @api.depends_context('uid')
    def _compute_privileged(self):
        self.privileged = is_su()


class AmbientRowProbe(models.Model):
    value = fields.Char(max_length=32)

    class Meta:
        app_label = 'contenttypes'
        managed = False


@pytest.fixture(autouse=True)
def isolated_environment():
    with transaction_scope(), context_scope(probe_key='ambient'):
        registry.clear_field_depends()
        yield
        registry.clear_field_depends()


def record():
    return RecordEnvironmentProbe._from_ids(ambient_env(), (31,), (31,))


def test_with_context_separates_computed_values_for_the_same_id():
    source = record()
    red = source.with_context(probe_key='red')
    blue = source.with_context(probe_key='blue')
    assert red.rendered == 'red'
    assert blue.rendered == 'blue'
    assert red.rendered == 'red'
    field = RecordEnvironmentProbe._meta.get_field('rendered')
    assert field._get_cache(red.env)[31] == 'red'
    assert field._get_cache(blue.env)[31] == 'blue'


def test_ambient_helpers_see_attached_context_during_compute_only():
    attached = record().with_context(probe_key='attached')
    assert attached.ambient_value == 'attached'
    assert get_context()['probe_key'] == 'ambient'


def test_explicit_assignment_uses_the_attached_cache_bucket():
    attached = record().with_context(probe_key='attached')
    attached.rendered = 'assigned'
    field = RecordEnvironmentProbe._meta.get_field('rendered')
    assert field._get_cache(attached.env)[31] == 'assigned'
    assert 31 not in field._get_cache(ambient_env())


def test_compute_exception_restores_ambient_context_and_scope_frames():
    attached = record().with_context(probe_key='attached')
    with pytest.raises(RuntimeError, match='compute failed'):
        _ = attached.failing
    assert get_context()['probe_key'] == 'ambient'
    assert not attached.env._tokens


def test_sudo_bucket_and_channel_do_not_leak_to_the_ambient_record():
    ordinary = record()
    elevated = ordinary.sudo()
    assert ordinary.privileged is False
    assert elevated.privileged is True
    assert ordinary.privileged is False
    assert is_su() is False


def test_class_access_preserves_the_descriptor():
    assert isinstance(RecordEnvironmentProbe.rendered, FieldDescriptor)


def test_plain_django_instance_keeps_its_existing_value():
    assert AmbientRowProbe(value='ordinary').value == 'ordinary'
